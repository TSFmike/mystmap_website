document.querySelector('.button').addEventListener('click', () => {
  alert('Coming soon: Online ordering for MysteryMapco games!');
});
